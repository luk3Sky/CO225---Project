# Fractal Explorer

### Running Application

Requirements: Java 1.7 or above

Using jar file to run application:
```bash
java -jar FractalExplorer.jar
```

Compile and run manually in terminal:
```bash
javac FractalExplorer.java
java FractalExplorer
```

### Some of the images found using this application include:

##### Fractal #1 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F8.png "Fractal #1 - Found by William Fiset")

##### Fractal #2 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F13.png "Fractal #2 - Found by William Fiset")

##### Fractal #3 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F10.png "Fractal #3 - Found by William Fiset")

##### Fractal #4 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F14.png "Fractal #4 - Found by William Fiset")

##### Fractal #5 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F17.png "Fractal #5 - Found by William Fiset")

##### Fractal #6 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F23.png "Fractal #6 - Found by William Fiset")

##### Fractal #7 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F24.png "Fractal #7 - Found by William Fiset")

##### Fractal #8 - Found by William Fiset
![Alt text](https://raw.githubusercontent.com/williamfiset/FractalExplorer/master/fractalImages/F25.png "Fractal #8 - Found by William Fiset")

